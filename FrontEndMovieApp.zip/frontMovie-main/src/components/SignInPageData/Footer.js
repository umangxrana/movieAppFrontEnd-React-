import React from "react";
const Footer=()=>{
    return (
        <div className="text-center">
            <h6>Designed by Umang Rana</h6>
        </div>
    )
}
export default Footer;
